return {
    name = "simplebookshelf",
    fullname = "SimpleBookshelf",
    description = "单设备版立体书脊式本地书架，支持书脊图片上传和 SimpleUI 导航栏。",
    version = "1.0.0-single",
}
