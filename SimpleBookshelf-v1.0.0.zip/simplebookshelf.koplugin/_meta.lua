return {
    name = "simplebookshelf",
    fullname = "SimpleBookshelf",
    description = "立体书脊式本地书架，支持书脊图片上传、共享库和 SimpleUI 导航栏。",
    version = "1.0.0",
}
