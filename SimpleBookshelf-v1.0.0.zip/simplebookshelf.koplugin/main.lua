local BB = require("ffi/blitbuffer")
local DataStorage = require("datastorage")
local Device = require("device")
local Dispatcher = require("dispatcher")
local Geom = require("ui/geometry")
local InputContainer = require("ui/widget/container/inputcontainer")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local lfs = require("libs/libkoreader-lfs")
local logger = require("logger")
local LuaSettings = require("luasettings")
local SimpleUI = require("simpleui_bridge")

local Screen = Device.screen
local PLUGIN_DIR = debug.getinfo(1, "S").source:sub(2):match("^(.*)/[^/]+$") or "."
local store = LuaSettings:open(DataStorage:getSettingsDir() .. "/simplebookshelf.lua")
local Cloud = dofile(PLUGIN_DIR .. "/spine_cloud.lua")
Cloud.configure(store)
local function cloudConfigured()
    local ok, value = pcall(Cloud.isConfigured)
    return ok and value == true
end

-- SimpleUI 2.5.0 moved its modules under infra/, features/, and screens/.
-- Keep one resolver for every integration point in this plugin: mixing the
-- new modules with the old root-level aliases creates a second Config/QA
-- registry and makes external navbar actions disappear when a shelf opens.
local GLOBAL_DEFAULTS = {
    sort_mode = "status",
    book_3d_level = 2,
    shelf_3d_level = 2,
    shelf_thickness = 24,
    shelf_rows = 3,
    embedded_font_size = 15,
    embedded_line_spacing = 30,
    standalone_font_size = 13,
    standalone_line_spacing = 34,
    book_left_margin_level = 2,
    book_right_margin_level = 2,
    book_top_margin_level = 3,
    scan_depth = 8,
    book_scale = 100,
}

local function globalSetting(key)
    local value = store:readSetting(key)
    if value == nil then return GLOBAL_DEFAULTS[key] end
    return value
end

local function saveGlobal(key, value)
    store:saveSetting(key, value)
    store:flush()
end

local function libraryRoot()
    return store:readSetting("library_root")
        or G_reader_settings:readSetting("home_dir")
        or "/mnt/us/documents"
end

local function loadOverrides()
    local value = store:readSetting("book_overrides")
    return type(value) == "table" and value or {}
end

local book_overrides = loadOverrides()

local function saveOverrides()
    store:saveSetting("book_overrides", book_overrides)
    store:flush()
end

local function closeSwitchBlocker()
    local blocker = UIManager._simpleui_external_switch_blocker
    if blocker then
        UIManager._simpleui_external_switch_blocker = nil
        pcall(function() UIManager:close(blocker) end)
    end
end

-- The shelf owns its wallpaper completely. It deliberately does not require
-- SimpleUI's old homescreen module or its split wallpaper feature: those two
-- implementations used different settings and caches, which was the source
-- of the selectable-but-blank wallpaper state.
local WALLPAPER_DEFAULT_DIR = DataStorage:getSettingsDir() .. "/simplebookshelf/wallpapers"

local function ensureDirectory(path)
    if lfs.attributes(path, "mode") == "directory" then return path end
    local parent = path:match("^(.*)/[^/]+$")
    if parent and parent ~= path then ensureDirectory(parent) end
    lfs.mkdir(path)
    return path
end

local function wallpaperDir()
    local path = store:readSetting("wallpaper_dir")
    if type(path) ~= "string" or path == "" then path = WALLPAPER_DEFAULT_DIR end
    if path ~= "/" then path = path:gsub("/+$", "") end
    return ensureDirectory(path)
end

local function setWallpaperDir(path)
    if type(path) ~= "string" or path == "" then path = WALLPAPER_DEFAULT_DIR end
    if path ~= "/" then path = path:gsub("/+$", "") end
    ensureDirectory(path)
    store:saveSetting("wallpaper_dir", path)
    -- A wallpaper selected from the previous directory must never silently
    -- remain active after the directory changes.
    store:saveSetting("wallpaper_path", false)
    store:saveSetting("wallpaper_enabled", false)
    store:flush()
end

local function wallpaperPath()
    local path = store:readSetting("wallpaper_path")
    if path == false then return nil end
    return type(path) == "string" and path or nil
end

local function setWallpaperPath(path)
    store:saveSetting("wallpaper_path", path or false)
    store:flush()
end

local function wallpaperEnabled()
    return store:readSetting("wallpaper_enabled") == true and wallpaperPath() ~= nil
end

local function setWallpaperEnabled(enabled)
    store:saveSetting("wallpaper_enabled", enabled ~= false)
    store:flush()
end

local function wallpaperFitMode()
    local mode = store:readSetting("wallpaper_fit_mode")
    if mode == "original" or mode == "stretch" or mode == "fill" then return mode end
    return "fill"
end

local function setWallpaperFitMode(mode)
    if mode ~= "original" and mode ~= "stretch" and mode ~= "fill" then mode = "fill" end
    store:saveSetting("wallpaper_fit_mode", mode)
    store:flush()
end

local function scanWallpapers()
    local dir = wallpaperDir()
    local items = {}
    local exts = { jpg=true, jpeg=true, png=true, bmp=true, gif=true, webp=true }
    if lfs.attributes(dir, "mode") == "directory" then
        for fname in lfs.dir(dir) do
            if fname ~= "." and fname ~= ".." then
                local ext = fname:match("%.([^%.]+)$")
                if ext and exts[ext:lower()] then
                    items[#items + 1] = {
                        label = fname:match("^(.+)%.[^%.]+$") or fname,
                        path = dir .. "/" .. fname,
                    }
                end
            end
        end
        table.sort(items, function(a, b) return a.label:lower() < b.label:lower() end)
    end
    return items
end

local function buildWallpaperWidget(path, width, height)
    if not path or lfs.attributes(path, "mode") ~= "file" then return nil end
    local ImageWidget = require("ui/widget/imagewidget")
    local fit = wallpaperFitMode()
    local ok, widget = pcall(function()
        if fit == "stretch" then
            return ImageWidget:new{file=path, width=width, height=height, alpha=true}
        end
        local probe = ImageWidget:new{file=path, scale_factor=1}
        probe:_render()
        local ow, oh = probe:getOriginalWidth(), probe:getOriginalHeight()
        probe:free()
        if not ow or not oh or ow <= 0 or oh <= 0 then return nil end
        local scale = fit == "fill" and math.max(width / ow, height / oh) or 1
        local image = ImageWidget:new{file=path, scale_factor=scale, alpha=true}
        local CenterContainer = require("ui/widget/container/centercontainer")
        return CenterContainer:new{dimen=Geom:new{w=width, h=height}, image}
    end)
    return ok and widget or nil
end

local function liveFileManager()
    local FM = package.loaded["apps/filemanager/filemanager"]
    return FM and FM.instance or nil
end

local function applicationIsClosing()
    -- _exit_code is assigned by UIManager:quit().  The poweroff/reboot path
    -- broadcasts Close before that assignment, so _entered_poweroff_stage is
    -- needed as the earlier signal too.
    return UIManager._exit_code ~= nil or UIManager._entered_poweroff_stage == true
end

local Shelf
local function closeShelfInstance()
    local shelf = Shelf and Shelf.instance
    if shelf and UIManager:isWidgetShown(shelf) then
        UIManager:close(shelf)
    elseif Shelf then
        Shelf.instance = nil
    end
end

local function stableHash(value)
    local hash = 5381
    for i = 1, #value do hash = (hash * 33 + value:byte(i)) % 2147483647 end
    return hash
end

local function defaultBookStyle(path, standalone)
    local h = stableHash(path)
    return {
        width = 48 + (h % 25),
        height_pct = 78 + (math.floor(h / 29) % 19),
        corner = 3 + (math.floor(h / 97) % 5),
        font_size = standalone and globalSetting("standalone_font_size") or globalSetting("embedded_font_size"),
        show_title = true,
        text_color = "white",
        title_vpos = "center",
        line_spacing = standalone and globalSetting("standalone_line_spacing") or globalSetting("embedded_line_spacing"),
        crop_align = "left",
        crop_pct = 20,
        spine_fit = "crop",
    }
end

local function bookStyle(path, standalone)
    local result = defaultBookStyle(path, standalone)
    local override = book_overrides[path]
    if type(override) == "table" then
        for key, value in pairs(override) do result[key] = value end
        -- Migrate the old relative gap setting to an absolute character spacing.
        if override.line_spacing == nil and override.line_gap ~= nil then
            result.line_spacing = math.max(result.font_size or 15, (result.font_size or 15) + override.line_gap)
        end
    end
    return result
end

local function updateBookStyle(path, key, value)
    if type(book_overrides[path]) ~= "table" then book_overrides[path] = {} end
    book_overrides[path][key] = value
    saveOverrides()
end

local function basename(path)
    return (path:match("([^/]+)$") or path):gsub("%.[^%.]+$", "")
end

local function utf8Chars(value)
    local result, i = {}, 1
    while i <= #value do
        local byte = value:byte(i)
        local length = byte < 128 and 1 or (byte < 224 and 2 or (byte < 240 and 3 or 4))
        result[#result + 1] = value:sub(i, i + length - 1)
        i = i + length
    end
    return result
end

local function simpleUIFontFace()
    local modules = SimpleUI.resolve()
    local style = modules and modules.Style
    return style and style.FACE_REGULAR or "cfont"
end

local TEXT_COLORS = {
    white = BB.COLOR_WHITE,
    pale = BB.COLOR_GRAY_E,
    light = BB.COLOR_GRAY_C,
    medium = BB.COLOR_GRAY_8,
    dark = BB.COLOR_GRAY_4,
    black = BB.COLOR_BLACK,
}

local function drawText(bb, value, x, y, size, bold, max_width, color)
    local Font = require("ui/font")
    local TextBoxWidget = require("ui/widget/textboxwidget")
    local TextWidget = require("ui/widget/textwidget")
    local options = {
        text = value,
        face = Font:getFace(simpleUIFontFace(), size),
        bold = bold,
        fgcolor = color or BB.COLOR_BLACK,
    }
    local widget
    if max_width then
        options.width = max_width
        options.max_lines = 1
        options.height_overflow_show_ellipsis = true
        options.alpha = true
        widget = TextBoxWidget:new(options)
    else
        widget = TextWidget:new(options)
    end
    widget:paintTo(bb, x, y)
    widget:free()
end

local function bookInfo(path, history_map)
    local book = {
        path = path,
        title = basename(path),
        authors = "",
        percent = 0,
        status = 2,
        added = lfs.attributes(path, "modification") or 0,
        last_read = history_map[path] or 0,
    }
    local ok_shared, shared = pcall(require, "desktop_modules/module_books_shared")
    if ok_shared and shared and shared.getBookData then
        local ok_data, data = pcall(shared.getBookData, path)
        if ok_data and data then
            book.title = data.title or book.title
            book.authors = data.authors or ""
            book.percent = data.percent or 0
        end
    end
    local ok_doc, DocSettings = pcall(require, "docsettings")
    if ok_doc then
        local ok_settings, settings = pcall(DocSettings.open, DocSettings, path)
        if ok_settings and settings then
            local summary = settings:readSetting("summary") or {}
            if book.percent == 0 then book.percent = settings:readSetting("percent_finished") or 0 end
            book.status = (summary.status == "complete" or book.percent >= 0.995) and 3
                or (book.percent > 0 and 1 or 2)
            pcall(function() settings:close() end)
        end
    end
    local ov = book_overrides[book.path]
    if ov and ov.title_override and ov.title_override ~= "" then book.title = ov.title_override end
    return book
end

local function historyMap()
    local result = {}
    local ok, history = pcall(require, "readhistory")
    if not ok or not history then return result end
    if not history.hist or #history.hist == 0 then pcall(function() history:reload() end) end
    for index, entry in ipairs(history.hist or {}) do
        if entry and entry.file then result[entry.file] = entry.time or entry.datetime or (#history.hist - index) end
    end
    return result
end

local function scanBooks(root)
    local DocumentRegistry = require("document/documentregistry")
    local result, hmap = {}, historyMap()
    local function walk(directory, depth)
        if depth > globalSetting("scan_depth") then return end
        local ok, iterator, state = pcall(lfs.dir, directory)
        if not ok then return end
        for name in iterator, state do
            if name ~= "." and name ~= ".." and name ~= ".sdr" and name:sub(1, 1) ~= "." then
                local path = directory .. "/" .. name
                local mode = lfs.attributes(path, "mode")
                if mode == "directory" then
                    walk(path, depth + 1)
                elseif mode == "file" and DocumentRegistry:hasProvider(path) then
                    result[#result + 1] = bookInfo(path, hmap)
                end
            end
        end
    end
    walk(root, 0)
    return result
end

local function scanBooksAsync(root, done)
    local DocumentRegistry = require("document/documentregistry")
    local result, hmap = {}, historyMap()
    local processed = 0
    local function walk(directory, depth)
        if depth > globalSetting("scan_depth") then return end
        local ok, iterator, state = pcall(lfs.dir, directory)
        if not ok then return end
        for name in iterator, state do
            if name ~= "." and name ~= ".." and name ~= ".sdr" and name:sub(1, 1) ~= "." then
                local path = directory .. "/" .. name
                local mode = lfs.attributes(path, "mode")
                if mode == "directory" then
                    walk(path, depth + 1)
                elseif mode == "file" and DocumentRegistry:hasProvider(path) then
                    result[#result + 1] = bookInfo(path, hmap)
                end
                processed = processed + 1
                if processed % 8 == 0 then coroutine.yield() end
            end
        end
    end
    local worker = coroutine.create(function()
        walk(root, 0)
        done(result)
    end)
    local function step()
        local ok, err = coroutine.resume(worker)
        if not ok then
            logger.warn("simplebookshelf: incremental scan failed:", err)
            done(nil)
            return
        end
        if coroutine.status(worker) ~= "dead" then UIManager:scheduleIn(.02, step) end
    end
    UIManager:nextTick(step)
end

-- Keep the expensive recursive scan out of navigation. A compact copy is
-- persisted so the shelf can paint immediately after KOReader starts; a
-- delayed rescan then reconciles newly imported books and reading progress.
local scan_cache = {}
local function cachedBooks(root)
    local memory = scan_cache[root]
    if memory then return memory end
    local saved = store:readSetting("scan_cache")
    if type(saved) == "table" and saved.root == root and type(saved.books) == "table" then
        scan_cache[root] = saved.books
        return saved.books
    end
    scan_cache[root] = {}
    return scan_cache[root]
end

local function booksSignature(books)
    local parts = {}
    for _, book in ipairs(books or {}) do
        parts[#parts + 1] = table.concat({
            book.path or "", book.added or 0, book.last_read or 0,
            book.status or 0, book.percent or 0, book.title or "",
        }, "\31")
    end
    table.sort(parts)
    return table.concat(parts, "\30")
end

local function sortBooks(books)
    local mode = globalSetting("sort_mode")
    table.sort(books, function(a, b)
        if mode == "title" then return a.title:lower() < b.title:lower() end
        if mode == "added" then return a.added == b.added and a.title < b.title or a.added > b.added end
        if mode == "read" then return a.last_read == b.last_read and a.title < b.title or a.last_read > b.last_read end
        if a.status ~= b.status then return a.status < b.status end
        if a.status == 1 and a.percent ~= b.percent then return a.percent > b.percent end
        return a.title:lower() < b.title:lower()
    end)
end

local function spinner(title, value, min_value, max_value, step, callback)
    local SpinWidget = require("ui/widget/spinwidget")
    UIManager:show(SpinWidget:new{
        title_text = title,
        value = value,
        value_min = min_value,
        value_max = max_value,
        value_step = step or 1,
        default_value = value,
        ok_text = "应用",
        cancel_text = "取消",
        callback = function(widget) callback(widget.value) end,
    })
end

-- Re-evaluate every visible menu's dynamic text_func/checked_func after a value
-- changes. KOReader only repaints a menu on setDirty("ui"); it does not rebuild
-- the item widgets, so labels driven by text_func would stay stale (showing the
-- default or previously-cached value) until the menu is reopened. Walking the
-- window stack and calling updateItems() on the topmost Menu forces a rebuild
-- of its item labels, which also covers nested submenus.
local function refreshTopMenu()
    local stack = UIManager._window_stack
    if not stack then return end
    for i = #stack, 1, -1 do
        local widget = stack[i] and stack[i].widget
        if widget and type(widget.updateItems) == "function" and widget.item_table then
            widget:updateItems()
            UIManager:setDirty(widget, "ui")
            return
        end
    end
end

local ShelfCanvas = WidgetContainer:extend{}
function ShelfCanvas:getSize() return Geom:new{ w = self.width, h = self.height } end

local DEPTH_BY_LEVEL = { 3, 6, 10, 15 }
local SOFTNESS_BY_LEVEL = { 12, 8, 4, 2 }
-- These are alpha-mask strengths, not opaque paint colours. The shadow is
-- composited over the wallpaper so its original tone remains visible.
local CORE_MASK_BY_LEVEL = {
    BB.COLOR_GRAY_4, BB.COLOR_GRAY_8, BB.COLOR_GRAY_B, BB.COLOR_GRAY_E,
}
local FEATHER_MASK_BY_LEVEL = {
    { BB.COLOR_GRAY_3, BB.COLOR_GRAY_2, BB.COLOR_GRAY_1 },
    { BB.COLOR_GRAY_6, BB.COLOR_GRAY_4, BB.COLOR_GRAY_2, BB.COLOR_GRAY_1 },
    { BB.COLOR_GRAY_8, BB.COLOR_GRAY_5, BB.COLOR_GRAY_2 },
    { BB.COLOR_GRAY_A, BB.COLOR_GRAY_4 },
}

local function dimensionalValues(key)
    local level = math.max(1, math.min(4, globalSetting(key) or 2))
    return DEPTH_BY_LEVEL[level], SOFTNESS_BY_LEVEL[level], CORE_MASK_BY_LEVEL[level], FEATHER_MASK_BY_LEVEL[level]
end

local blend_mask, blend_mask_w, blend_mask_h
local function blendRect(target_bb, x, y, w, h, alpha_mask)
    if w <= 0 or h <= 0 then return end
    if not blend_mask or w > blend_mask_w or h > blend_mask_h then
        if blend_mask and blend_mask.free then blend_mask:free() end
        blend_mask_w = math.max(w, blend_mask_w or 0)
        blend_mask_h = math.max(h, blend_mask_h or 0)
        blend_mask = BB.new(blend_mask_w, blend_mask_h, BB.TYPE_BB8)
    end
    if not blend_mask then return end
    blend_mask:paintRect(0, 0, w, h, alpha_mask)
    target_bb:colorblitFromRGB32(blend_mask, x, y, 0, 0, w, h, BB.COLOR_BLACK)
end

local function paintSoftShadow(bb, x, y, w, h, depth, softness, core_color, feather_colors)
    if depth <= 0 then return end
    softness = math.max(0, softness or 0)
    local colors = feather_colors or { BB.COLOR_GRAY_A, BB.COLOR_GRAY_C, BB.COLOR_GRAY_E }
    -- A dark contact shadow followed by increasingly pale one-pixel bands
    -- gives the e-ink panel a visibly feathered edge instead of a hard offset.
    blendRect(bb, x + w, y + depth, depth, math.max(1, h - depth), core_color or BB.COLOR_GRAY_8)
    blendRect(bb, x + depth, y + h, math.max(1, w - depth), depth, core_color or BB.COLOR_GRAY_8)
    for band = 1, softness do
        local color_index = math.min(#colors, math.max(1, math.ceil(band * #colors / math.max(1, softness))))
        local color = colors[color_index]
        local offset = depth + band
        blendRect(bb, x + w + depth + band - 1, y + offset, 1, math.max(1, h - offset), color)
        blendRect(bb, x + offset, y + h + depth + band - 1, math.max(1, w - offset), 1, color)
    end
end

local function paintTopRoundedWidget(widget, target_bb, x, y, w, h, radius)
    radius = math.max(0, math.min(radius or 0, math.floor(math.min(w, h) / 2)))
    if radius == 0 then widget:paintTo(target_bb, x, y); return end
    local tmp = BB.new(w, h, target_bb:getType())
    if not tmp then widget:paintTo(target_bb, x, y); return end
    tmp:fill(BB.COLOR_WHITE)
    widget:paintTo(tmp, 0, 0)
    local function insetAt(row)
        if row >= radius then return 0 end
        local dy = radius - row
        return math.max(0, math.ceil(radius - math.sqrt(math.max(0, radius * radius - dy * dy))))
    end
    local row = 0
    while row < h do
        local inset = insetAt(row)
        local run = 1
        while row + run < h and insetAt(row + run) == inset do run = run + 1 end
        local span = w - inset * 2
        if span > 0 then target_bb:blitFrom(tmp, x + inset, y + row, inset, row, span, run) end
        row = row + run
    end
    tmp:free()
end

local function paintBookEdgeHighlight(bb, x, y, w, h, level, corner)
    if level < 2 then return end
    local colors = { BB.COLOR_GRAY_E, BB.COLOR_GRAY_C, BB.COLOR_GRAY_A, BB.COLOR_GRAY_8 }
    local bands = math.min(#colors, level - 1)
    local top = y + math.max(2, corner or 0)
    local height = math.max(1, h - math.max(2, corner or 0))
    for band = 1, bands do
        -- Brightest at the book/shadow boundary, fading softly into the cover.
        bb:paintRect(x + w - band, top, 1, height, colors[band])
    end
end

local function paintShelfEdgeHighlight(bb, x, y, w, level)
    if level < 2 then return end
    local colors = { BB.COLOR_GRAY_E, BB.COLOR_GRAY_C, BB.COLOR_GRAY_A }
    local bands = math.min(#colors, level - 1)
    for band = 1, bands do
        -- Brightest at the shelf/shadow boundary, fading upward into the shelf.
        bb:paintRect(x, y - band, w, 1, colors[band])
    end
end

local function customSpineWidget(path, w, h, fit)
    if not path or lfs.attributes(path, "mode") ~= "file" then return nil end
    local ImageWidget = require("ui/widget/imagewidget")
    local ok, widget = pcall(function()
        -- Do not probe/render the original phone photo first. ImageWidget's
        -- scale_factor path decodes the native image and only then scales it,
        -- which can retain several multi-megapixel buffers on Scribe. Passing
        -- the target dimensions makes RenderImage downsample during decode.
        -- The shelf card is narrow enough that the tiny aspect-ratio tradeoff
        -- is preferable to a memory spike and keeps all uploaded formats safe.
        return ImageWidget:new{
            file=path, width=w, height=h, alpha=true, file_do_cache=false,
        }
    end)
    return ok and widget or nil
end

function ShelfCanvas:paintTo(bb, origin_x, origin_y)
    local owner, width, height = self.owner, self.width, self.height
    bb:paintRect(origin_x, origin_y, width, height, BB.COLOR_WHITE)
    owner:paintWallpaper(bb, origin_x, origin_y)
    owner.hit_books = {}
    local rows = math.max(1, math.min(5, globalSetting("shelf_rows") or 3))
    local row_height = math.floor(height / rows)
    local book_shadow, book_soft, book_core, book_feather = dimensionalValues("book_3d_level")
    local book_3d_level = math.max(1, math.min(4, globalSetting("book_3d_level") or 2))
    local shelf_shadow, shelf_soft, shelf_core, shelf_feather = dimensionalValues("shelf_3d_level")
    local shelf_3d_level = math.max(1, math.min(4, globalSetting("shelf_3d_level") or 2))
    local shelf_thickness = globalSetting("shelf_thickness")
    for row = 1, rows do
        local top = origin_y + (row - 1) * row_height
        local baseline = top + row_height - 15
        bb:paintRect(origin_x + 7, baseline, width - 14, shelf_thickness, BB.COLOR_GRAY_4)
        bb:paintRect(origin_x + 7, baseline, width - 14, 2, BB.COLOR_BLACK)
        paintShelfEdgeHighlight(bb, origin_x + 7, baseline + shelf_thickness, width - 14, shelf_3d_level)
        if shelf_shadow > 0 then
            local shadow_y = baseline + shelf_thickness
            blendRect(bb, origin_x + 7, shadow_y, width - 14, shelf_shadow, shelf_core)
            for band = 1, shelf_soft do
                local ci = math.min(#shelf_feather, math.max(1, math.ceil(band * #shelf_feather / shelf_soft)))
                blendRect(bb, origin_x + 8, shadow_y + shelf_shadow + band - 1, width - 16, 1, shelf_feather[ci])
            end
        end
    end

    local page = owner.pages[owner.page] or {}
    local ok_shared, shared = pcall(require, "desktop_modules/module_books_shared")
    for _, placement in ipairs(page) do
        local book, style = placement.book, placement.style
        local x = origin_x + placement.x
        local y = origin_y + placement.y
        local w, h = placement.w, placement.h
        paintSoftShadow(bb, x, y, w, h, book_shadow, book_soft, book_core, book_feather)
        bb:paintRoundedRect(x, y, w, h, BB.COLOR_GRAY_4, style.corner)
        if style.corner > 0 then
            bb:paintRect(x, y + style.corner, w, math.max(1, h - style.corner), BB.COLOR_GRAY_4)
        end

        local cover = customSpineWidget(style.custom_spine, math.max(1, w - 4), math.max(1, h - 2), style.spine_fit)
        if not cover and ok_shared and shared and shared.getBookCover then
            local ok_cover, widget = pcall(shared.getBookCover, book.path, math.max(1, w - 4), math.max(1, h - 2), style.crop_align, nil)
            if ok_cover then cover = widget end
        end
        if cover then
            paintTopRoundedWidget(cover, bb, x + 2, y + 2, math.max(1, w - 4), math.max(1, h - 2), math.max(0, style.corner - 2))
            if cover.free then cover:free() end
        end
        paintBookEdgeHighlight(bb, x, y, w, h, book_3d_level, style.corner)

        if style.show_title ~= false then
        local letters = utf8Chars(book.title)
        local font_size = style.font_size or 15
        local line_step = math.max(3, style.line_spacing or 20)
        local column_step = font_size + 2
        local lines = math.max(1, math.floor((h - 12) / line_step))
        local columns = math.max(1, math.floor((w - 8) / column_step))
        local visible_count = math.min(#letters, lines * columns)
        local used_columns = math.max(1, math.ceil(visible_count / lines))
        local block_width = used_columns * column_step
        local block_left = x + math.floor((w - block_width) / 2)
        local longest_column = math.min(lines, visible_count)
        local block_height = (longest_column - 1) * line_step + font_size
        local block_top = y + math.floor((h - block_height) / 2)
        if style.title_vpos == "top" then block_top = y + 6
        elseif style.title_vpos == "upper" then block_top = y + math.floor((h - block_height) / 4)
        elseif style.title_vpos == "lower" then block_top = y + math.floor((h - block_height) * 3 / 4)
        elseif style.title_vpos == "bottom" then block_top = y + h - block_height - 6 end
        local index = 1
        local color = TEXT_COLORS[style.text_color] or BB.COLOR_WHITE
        for column = 1, used_columns do
            for line = 1, lines do
                if not letters[index] then break end
                local tx = block_left + (used_columns - column) * column_step
                local ty = block_top + (line - 1) * line_step
                drawText(bb, letters[index], tx, ty, font_size, true, nil, color)
                index = index + 1
            end
        end
        end
        owner.hit_books[#owner.hit_books + 1] = { x=x, y=y, w=w, h=h, book=book }
    end
end

Shelf = InputContainer:extend{ name = "simplebookshelf_window", covers_fullscreen = true }

function Shelf:buildPages()
    self.pages = {}
    local screen_width = Screen:getWidth()
    local content_height = self.content_height
    local rows = math.max(1, math.min(5, globalSetting("shelf_rows") or 3))
    local row_height = math.floor(content_height / rows)
    local side_margin_pct = { .006, .015, .035, .07, .12 }
    local top_margin_pct = { .04, .08, .14, .23, .34 }
    local left_level = math.max(1, math.min(5, globalSetting("book_left_margin_level") or 2))
    local right_level = math.max(1, math.min(5, globalSetting("book_right_margin_level") or 2))
    local top_level = math.max(1, math.min(5, globalSetting("book_top_margin_level") or 3))
    local left_margin = math.floor(screen_width * side_margin_pct[left_level])
    local right_margin = math.floor(screen_width * side_margin_pct[right_level])
    local top_margin = math.floor(row_height * top_margin_pct[top_level])
    local gap = 3
    local page, row, cursor = {}, 1, left_margin
    for _, book in ipairs(self.books) do
        local style = bookStyle(book.path, self.standalone)
        local scale = (globalSetting("book_scale") or 100) / 100
        local w = math.max(28, math.min(150, math.floor(style.width * scale)))
        if cursor + w > screen_width - right_margin then row, cursor = row + 1, left_margin end
        if row > rows then
            self.pages[#self.pages + 1] = page
            page, row, cursor = {}, 1, left_margin
        end
        local h = math.floor((row_height - top_margin) * math.max(55, math.min(100, style.height_pct)) / 100 * scale)
        h = math.max(20, math.min(row_height - 18, h))
        local baseline = row * row_height - 15
        page[#page + 1] = { book=book, style=style, x=cursor, y=baseline-h, w=w, h=h }
        cursor = cursor + w + gap
    end
    self.pages[#self.pages + 1] = page
    if #self.pages == 0 then self.pages = { {} } end
    self.page_num = #self.pages
    self.page = math.max(1, math.min(self.page or 1, self.page_num))
end

function Shelf:init()
    local GestureRange = require("ui/gesturerange")
    self.sui_plugin = self.sui_plugin
    local modules = SimpleUI.resolve()
    local UI = modules and modules.UI
    local Config = modules and modules.Config
    local has_simpleui = not self.standalone and UI and Config
    self.content_height = has_simpleui and UI.getContentHeight() or Screen:getHeight()
    self.page = 1
    self.scan_root = libraryRoot()
    self.books = cachedBooks(self.scan_root)
    sortBooks(self.books)
    self:buildPages()

    self.canvas = ShelfCanvas:new{ width=Screen:getWidth(), height=self.content_height, owner=self }
    self.canvas.dimen = Geom:new{ w=Screen:getWidth(), h=self.content_height }
    if has_simpleui then
        local tabs = Config.loadTabConfig()
        local container, wrapped, bar, topbar, bar_index, topbar_on, topbar_index =
            UI.wrapWithNavbar(self.canvas, "simplebookshelf", tabs)
        UI.applyNavbarState(self, container, bar, topbar, bar_index, topbar_on, topbar_index, tabs)
        self._navbar_inner = self.canvas
        self._navbar_injected = true
        self[1] = wrapped
        UI.applyGesturePriorityHandleEvent(self)
    else
        -- Plain KOReader fallback: the same shelf fills the screen and closes
        -- through the normal Back/Close event. No SimpleUI files are required.
        self[1] = self.canvas
    end
    self.dimen = Geom:new{ x=0, y=0, w=Screen:getWidth(), h=Screen:getHeight() }

    local range = function() return self.dimen end
    -- Keep the top-of-screen swipe available to KOReader/SimpleUI.  The
    -- shelf itself only needs page swipes from the content area; registering
    -- a full-screen swipe here would win over SimpleUI's menu gesture.
    local swipe_range = function()
        local top = 0
        if has_simpleui then
            pcall(function()
                local Topbar = require("sui_topbar")
                if Topbar and Topbar.TOTAL_TOP_H then
                    top = tonumber(Topbar.TOTAL_TOP_H()) or 0
                end
            end)
        end
        return Geom:new{
            x = 0,
            y = top,
            w = Screen:getWidth(),
            h = math.max(1, Screen:getHeight() - top),
        }
    end

    -- A shelf page is not FileManagerMenu, so SimpleUI's normal top-menu
    -- zones are not installed automatically. Install the same swipe/tap
    -- entry point here and resolve the live menu at gesture time.
    if has_simpleui and self.registerTouchZones then
        local top_menu_ratio = 0.15
        pcall(function()
            local Topbar = require("sui_topbar")
            local UI_core = require("sui_core")
            if Topbar and Topbar.TOTAL_TOP_H then
                top_menu_ratio = (Topbar.TOTAL_TOP_H()
                    + ((UI_core and UI_core.MOD_GAP) or 0)) / Screen:getHeight()
            end
        end)
        local function liveMenu()
            local plugin = self.sui_plugin
            local fm = plugin and plugin.ui
            if fm and fm.menu then return fm.menu end
            local FM = package.loaded["apps/filemanager/filemanager"]
            local inst = FM and FM.instance
            return inst and inst.menu or nil
        end
        self:registerTouchZones({
            {
                id = "simplebookshelf_menu_tap",
                ges = "tap",
                screen_zone = { ratio_x=0, ratio_y=0, ratio_w=1, ratio_h=top_menu_ratio },
                handler = function(ges)
                    local menu = liveMenu()
                    if menu and menu.onTapShowMenu then
                        return menu:onTapShowMenu(ges)
                    end
                    return false
                end,
            },
            {
                id = "simplebookshelf_menu_swipe",
                ges = "swipe",
                screen_zone = { ratio_x=0, ratio_y=0, ratio_w=1, ratio_h=top_menu_ratio },
                handler = function(ges)
                    local menu = liveMenu()
                    if menu and menu.onSwipeShowMenu then
                        return menu:onSwipeShowMenu(ges)
                    end
                    return false
                end,
            },
        })
    end
    self.ges_events = {
        TapBook = { GestureRange:new{ ges="tap", range=range } },
        HoldBook = { GestureRange:new{ ges="hold", range=range } },
        SwipePage = { GestureRange:new{ ges="swipe", range=swipe_range } },
    }
    if self.sui_plugin and self.sui_plugin._registerTouchZones then self.sui_plugin:_registerTouchZones(self) end

    -- Let the cached page reach the e-ink screen before touching storage.
    UIManager:scheduleIn(.25, function()
        if Shelf.instance == self then self:refreshBooks(false) end
    end)
end

-- Paint the shelf-owned wallpaper. No SimpleUI wallpaper API is involved.
function Shelf:paintWallpaper(bb, x, y)
    local path = wallpaperEnabled() and wallpaperPath() or nil
    local width = self.canvas and self.canvas.width or Screen:getWidth()
    local height = self.canvas and self.canvas.height or Screen:getHeight()
    local fit = wallpaperFitMode()
    if not path then
        self:clearWallpaperCache()
        return false
    end

    if self._wallpaper_widget and self._wallpaper_path == path
            and self._wallpaper_fit == fit then
        local ok = pcall(self._wallpaper_widget.paintTo, self._wallpaper_widget, bb, x or 0, y or 0)
        return ok
    end

    self:clearWallpaperCache()
    self._wallpaper_path = path
    self._wallpaper_fit = fit
    local ok, widget = pcall(buildWallpaperWidget, path, width, height)
    if ok and widget then
        self._wallpaper_widget = widget
        local painted = pcall(widget.paintTo, widget, bb, x or 0, y or 0)
        if painted then return true end
    end
    self._wallpaper_path = nil
    self._wallpaper_fit = nil
    return false
end

function Shelf:clearWallpaperCache()
    if self._wallpaper_widget and self._wallpaper_widget.free then
        pcall(self._wallpaper_widget.free, self._wallpaper_widget)
    end
    self._wallpaper_widget = nil
    self._wallpaper_path = nil
    self._wallpaper_fit = nil
end

function Shelf:refreshBooks(force)
    if self._scan_running then return end
    local now = os.time()
    if not force and self._last_scan_at and now - self._last_scan_at < 60 then return end
    self._scan_running = true
    local old_signature = booksSignature(self.books)
    scanBooksAsync(self.scan_root, function(books)
        self._scan_running = false
        self._last_scan_at = os.time()
        if type(books) ~= "table" then return end
        scan_cache[self.scan_root] = books
        store:saveSetting("scan_cache", { root = self.scan_root, books = books, saved_at = self._last_scan_at })
        store:flush()
        if force or booksSignature(books) ~= old_signature then
            self.books = books
            sortBooks(self.books)
            self:buildPages()
            UIManager:setDirty(self, "ui")
        end
    end)
end

function Shelf:setLibraryRoot(path)
    if path and path ~= "" then
        path = path == "/" and "/" or path:gsub("/+$", "")
        store:saveSetting("library_root", path)
    else
        store:delSetting("library_root")
        path = G_reader_settings:readSetting("home_dir") or "/mnt/us/documents"
    end
    store:delSetting("scan_cache")
    store:flush()
    scan_cache = {}
    self.scan_root = path
    self.books = {}
    self.page = 1
    self:buildPages()
    UIManager:setDirty(self, "ui")
    self._last_scan_at = nil
    self:refreshBooks(true)
end

function Shelf:bookAt(position)
    for _, hit in ipairs(self.hit_books or {}) do
        if position.x >= hit.x and position.x <= hit.x + hit.w and position.y >= hit.y and position.y <= hit.y + hit.h then
            return hit.book
        end
    end
end

function Shelf:onTapBook(_, gesture)
    local book = self:bookAt(gesture.pos)
    if not book then return false end
    G_reader_settings:saveSetting("simplebookshelf_return_pending", true)
    G_reader_settings:saveSetting("simplebookshelf_return_page", self.page or 1)
    if self.standalone then
        G_reader_settings:saveSetting("simplebookshelf_return_standalone", true)
        G_reader_settings:delSetting("simpleui_book_origin")
        UIManager._simpleui_book_origin = nil
    else
        G_reader_settings:delSetting("simplebookshelf_return_standalone")
        G_reader_settings:saveSetting("simpleui_book_origin", "simplebookshelf")
        -- Process-local provenance is visible immediately to every plugin and
        -- is not sensitive to settings flush/event dispatch ordering.
        UIManager._simpleui_book_origin = "simplebookshelf"
    end
    G_reader_settings:flush()
    -- Do not park this widget underneath ReaderUI.  The FileManager and its
    -- SimpleUI plugin are recreated across a reader session; keeping the old
    -- shelf alive leaves its navbar callbacks bound to the old host.  Save
    -- the page above and rebuild a fresh shelf on the next CloseDocument.
    UIManager:close(self)
    require("apps/reader/readerui"):showReader(book.path)
    return true
end

function Shelf:onHoldBook(_, gesture)
    local book = self:bookAt(gesture.pos)
    if not book then self:showGlobalSettings(); return true end
    self:showBookEditor(book)
    return true
end

function Shelf:onSwipePage(_, gesture)
    if gesture.direction == "west" and self.page < self.page_num then self.page = self.page + 1
    elseif gesture.direction == "east" and self.page > 1 then self.page = self.page - 1
    else return false end
    UIManager:setDirty(self, "ui")
    return true
end

function Shelf:onNextPage() if self.page < self.page_num then self.page=self.page+1;UIManager:setDirty(self,"ui") end return true end
function Shelf:onPrevPage() if self.page > 1 then self.page=self.page-1;UIManager:setDirty(self,"ui") end return true end
function Shelf:onGotoPage(page) self.page=math.max(1,math.min(page,self.page_num));UIManager:setDirty(self,"ui");return true end

function Shelf:refreshLayout()
    self:buildPages()
    UIManager:setDirty(self, "ui")
end

-- A spine image changes only one placement. Rebuilding every page here is
-- needlessly expensive on Scribe and can decode all custom images again.
function Shelf:updateBookSpine(book_path, image_path)
    for _, page in ipairs(self.pages or {}) do
        for _, placement in ipairs(page) do
            if placement.book and placement.book.path == book_path and placement.style then
                placement.style.custom_spine = image_path
            end
        end
    end
    UIManager:setDirty(self, "ui")
end

function Shelf:showBookEditor(book)
    local Menu = require("ui/widget/menu")
    local style = bookStyle(book.path, self.standalone)
    local editor_menu
    local function set(key, value)
        updateBookStyle(book.path, key, value)
        self:refreshLayout()
        refreshTopMenu()
    end
    local items = {
        { text="外观", sub_item_table={
            { text="宽度", sub_item_table={
                {text="一档 · 最窄",checked_func=function()return style.width==38 end,callback=function()style.width=38;set("width",38)end},
                {text="二档 · 较窄",checked_func=function()return style.width==50 end,callback=function()style.width=50;set("width",50)end},
                {text="三档 · 适中",checked_func=function()return style.width==65 end,callback=function()style.width=65;set("width",65)end},
                {text="四档 · 较宽",checked_func=function()return style.width==85 end,callback=function()style.width=85;set("width",85)end},
                {text="五档 · 最宽",checked_func=function()return style.width==110 end,callback=function()style.width=110;set("width",110)end},
            }},
            { text="高度", sub_item_table={
                {text="一档 · 最矮",checked_func=function()return style.height_pct==60 end,callback=function()style.height_pct=60;set("height_pct",60)end},
                {text="二档 · 较矮",checked_func=function()return style.height_pct==70 end,callback=function()style.height_pct=70;set("height_pct",70)end},
                {text="三档 · 适中",checked_func=function()return style.height_pct==80 end,callback=function()style.height_pct=80;set("height_pct",80)end},
                {text="四档 · 较高",checked_func=function()return style.height_pct==90 end,callback=function()style.height_pct=90;set("height_pct",90)end},
                {text="五档 · 最高",checked_func=function()return style.height_pct==100 end,callback=function()style.height_pct=100;set("height_pct",100)end},
            }},
            { text="圆角", sub_item_table={
                {text="一档 · 直角",checked_func=function()return style.corner==0 end,callback=function()style.corner=0;set("corner",0)end},
                {text="二档 · 轻微",checked_func=function()return style.corner==3 end,callback=function()style.corner=3;set("corner",3)end},
                {text="三档 · 自然",checked_func=function()return style.corner==6 end,callback=function()style.corner=6;set("corner",6)end},
                {text="四档 · 明显",checked_func=function()return style.corner==10 end,callback=function()style.corner=10;set("corner",10)end},
                {text="五档 · 很圆",checked_func=function()return style.corner==16 end,callback=function()style.corner=16;set("corner",16)end},
            }},
        }},
        { text="书名", sub_item_table={
            { text_func=function() return "显示书名："..(style.show_title == false and "关" or "开") end,
              callback=function()
                  style.show_title = style.show_title == false
                  set("show_title", style.show_title)
              end },
            { text_func=function() return "字号："..style.font_size end, callback=function()spinner("书名字号",style.font_size,3,48,1,function(v)style.font_size=v;set("font_size",v)end)end },
            { text_func=function() return "字距："..(style.line_spacing or 20) end, callback=function()spinner("书名纵向字距",style.line_spacing or 20,3,80,1,function(v)style.line_spacing=v;set("line_spacing",v)end)end },
            { text="位置", sub_item_table={
                {text="顶部",checked_func=function()return style.title_vpos=="top"end,callback=function()style.title_vpos="top";set("title_vpos","top")end},
                {text="偏上",checked_func=function()return style.title_vpos=="upper"end,callback=function()style.title_vpos="upper";set("title_vpos","upper")end},
                {text="居中",checked_func=function()return style.title_vpos=="center"end,callback=function()style.title_vpos="center";set("title_vpos","center")end},
                {text="偏下",checked_func=function()return style.title_vpos=="lower"end,callback=function()style.title_vpos="lower";set("title_vpos","lower")end},
                {text="底部",checked_func=function()return style.title_vpos=="bottom"end,callback=function()style.title_vpos="bottom";set("title_vpos","bottom")end},
            }},
            { text="颜色", sub_item_table={
                {text="白色",checked_func=function()return style.text_color=="white"end,callback=function()style.text_color="white";set("text_color","white")end},
                {text="近白",checked_func=function()return style.text_color=="pale"end,callback=function()style.text_color="pale";set("text_color","pale")end},
                {text="浅灰",checked_func=function()return style.text_color=="light"end,callback=function()style.text_color="light";set("text_color","light")end},
                {text="中灰",checked_func=function()return style.text_color=="medium"end,callback=function()style.text_color="medium";set("text_color","medium")end},
                {text="深灰",checked_func=function()return style.text_color=="dark"end,callback=function()style.text_color="dark";set("text_color","dark")end},
                {text="黑色",checked_func=function()return style.text_color=="black"end,callback=function()style.text_color="black";set("text_color","black")end},
            }},
        }},
        { text="书脊", sub_item_table={
            { text="图片", sub_item_table={
                { text_func=function() return "默认封面"..(style.custom_spine and "" or "  ✓") end,
                  callback=function()
                      style.custom_spine=nil
                      set("custom_spine",nil)
                  end },
                { text="手机上传", callback=function()
                    local InfoMessage=require("ui/widget/infomessage")
                    local ok_uploader,Uploader=pcall(function()
                        if not package.loaded.simplebookshelf_spine_upload then
                            package.loaded.simplebookshelf_spine_upload=dofile(PLUGIN_DIR.."/spine_upload.lua")
                        end
                        return package.loaded.simplebookshelf_spine_upload
                    end)
                    if not ok_uploader then UIManager:show(InfoMessage:new{text="上传组件无法加载",timeout=3});return end
                    local url,err=Uploader.start(book.path,function(path)
                        style.custom_spine=path
                        updateBookStyle(book.path,"custom_spine",path)
                        -- Let the upload dialog/server finish and repaint the
                        -- local shelf before doing any optional WebDAV work.
                        -- Calling both immediately used to make Scribe appear
                        -- frozen while the new image was decoded and the
                        -- network request was still running.
                        UIManager:scheduleIn(0.15, function()
                            if Shelf.instance == self then self:updateBookSpine(book.path,path) end
                        end)
                        local cloud_configured = false
                        pcall(function() cloud_configured = Cloud.isConfigured() end)
                        if cloud_configured then
                            UIManager:show(InfoMessage:new{
                                text = "书脊已上传，本地已保存；共享库稍后同步",
                                timeout = 3,
                            })
                            UIManager:scheduleIn(1.0, function()
                                local call_ok, synced, sync_err = pcall(Cloud.upload, book.path, path)
                                if not call_ok then synced, sync_err = false, tostring(synced) end
                                UIManager:show(InfoMessage:new{
                                    text = synced and "书脊已同步到共享库"
                                        or ("共享库同步失败：" .. tostring(sync_err or "未知错误")),
                                    timeout = 4,
                                })
                            end)
                        else
                            UIManager:show(InfoMessage:new{text="自定义书脊上传成功",timeout=3})
                        end
                    end)
                    if not url then UIManager:show(InfoMessage:new{text=err or "无法开始上传",timeout=3}) end
                end },
                { text="从共享库获取", enabled_func=function() return cloudConfigured() end,
                  callback=function()
                      local InfoMessage=require("ui/widget/infomessage")
                      local cache_dir=DataStorage:getSettingsDir().."/simplebookshelf_spines"
                      UIManager:show(InfoMessage:new{text="正在从共享库获取…",timeout=45})
                      local async_ok = pcall(function()
                          Cloud.downloadAsync(book.path, cache_dir, function(path, err)
                              if path then
                                  style.custom_spine=path
                                  updateBookStyle(book.path,"custom_spine",path)
                                  UIManager:scheduleIn(0.1, function()
                                      if Shelf.instance == self then self:updateBookSpine(book.path,path) end
                                  end)
                                  UIManager:show(InfoMessage:new{text="已从共享库获取书脊图片",timeout=3})
                              else
                                  UIManager:show(InfoMessage:new{text=err or "共享库中没有这本书",timeout=4})
                              end
                          end)
                      end)
                      if not async_ok then
                          UIManager:show(InfoMessage:new{text="共享库下载组件启动失败",timeout=4})
                      end
                  end },
                { text="上传当前图片到共享库",
                  enabled_func=function() return style.custom_spine ~= nil and cloudConfigured() end,
                  callback=function()
                      local InfoMessage=require("ui/widget/infomessage")
                      local call_ok,ok,err=pcall(Cloud.upload,book.path,style.custom_spine)
                      if not call_ok then ok,err=false,tostring(ok) end
                      UIManager:show(InfoMessage:new{
                          text=ok and "当前书脊图片已上传到共享库"
                              or (err or "上传共享书脊失败"), timeout=4,
                      })
                  end },
                { text="删除自定义图片", enabled_func=function()return style.custom_spine~=nil end,
                  callback=function()
                      if style.custom_spine then pcall(os.remove,style.custom_spine) end
                      style.custom_spine=nil
                      set("custom_spine",nil)
                  end },
            }},
            { text="适配方式", sub_item_table={
                {text="保持比例并裁切",checked_func=function()return style.spine_fit=="crop"end,callback=function()style.spine_fit="crop";set("spine_fit","crop")end},
                {text="拉伸填满",checked_func=function()return style.spine_fit=="stretch"end,callback=function()style.spine_fit="stretch";set("spine_fit","stretch")end},
            }},
            { text="取图", sub_item_table={
                {text="左侧",checked_func=function()return style.crop_align=="left"end,callback=function()style.crop_align="left";set("crop_align","left")end},
                {text="中间",checked_func=function()return style.crop_align=="center"end,callback=function()style.crop_align="center";set("crop_align","center")end},
                {text="右侧",checked_func=function()return style.crop_align=="right"end,callback=function()style.crop_align="right";set("crop_align","right")end},
            }},
            { text_func=function() return "宽度："..style.crop_pct.."%" end, callback=function()spinner("封面截取宽度",style.crop_pct,8,60,1,function(v)style.crop_pct=v;set("crop_pct",v)end)end },
        }},
        { text="恢复默认",callback=function()book_overrides[book.path]=nil;saveOverrides();self:refreshLayout()end },
    }
    editor_menu = Menu:new{ title="编辑：《"..book.title.."》", item_table=items,
        width=math.floor(Screen:getWidth()*.72),height=math.floor(Screen:getHeight()*.82) }
    UIManager:show(editor_menu)
end

function Shelf:showGlobalSettings()
    local Menu = require("ui/widget/menu")
    local settings_menu
    local function setGlobalAndPaint(key, value)
        saveGlobal(key, value)
        if key == "shelf_rows" or key == "book_left_margin_level" or key == "book_right_margin_level"
                or key == "book_top_margin_level" or key == "book_scale" then
            self:buildPages()
        end
        UIManager:setDirty(self,"ui")
        refreshTopMenu()
    end
    local function fiveLevels(key, values, labels)
        local result = {}
        for i, value in ipairs(values) do
            local saved_value, label = value, labels[i]
            result[#result + 1] = {
                text = label,
                checked_func = function() return globalSetting(key) == saved_value end,
                callback = function() setGlobalAndPaint(key, saved_value) end,
            }
        end
        return result
    end
    local function setTypography(key, value)
        saveGlobal(key, value)
        self:buildPages()
        UIManager:setDirty(self, "ui")
        refreshTopMenu()
    end
    local wallpaper_items = {
        { text="不使用壁纸", callback=function()
            setWallpaperPath(nil)
            setWallpaperEnabled(false)
            self:clearWallpaperCache()
            UIManager:setDirty(self,"ui")
        end },
    }
    for _, wallpaper in ipairs(scanWallpapers()) do
        local item = wallpaper
        wallpaper_items[#wallpaper_items+1] = {
            text=item.label,
            checked_func=function() return wallpaperEnabled() and wallpaperPath() == item.path end,
            callback=function()
                setWallpaperPath(item.path)
                setWallpaperEnabled(true)
                self:clearWallpaperCache()
                UIManager:setDirty(self,"ui")
            end,
        }
    end
    local wallpaper_folder_items = {
        {text_func=function() return "当前：" .. wallpaperDir() end, enabled_func=function() return false end},
        {text="使用书柜默认文件夹", callback=function()
            if settings_menu then UIManager:close(settings_menu) end
            setWallpaperDir(nil)
            UIManager:setDirty(self, "ui")
            refreshTopMenu()
        end},
        {text="选择其他文件夹…", callback=function()
            if settings_menu then UIManager:close(settings_menu) end
            local PathChooser = require("ui/widget/pathchooser")
            UIManager:show(PathChooser:new{
                path=wallpaperDir(), select_directory=true, select_file=false, show_files=false,
                onConfirm=function(folder)
                    setWallpaperDir(folder)
                    UIManager:setDirty(self, "ui")
                    refreshTopMenu()
                end,
            })
        end},
    }
    local sort_items = {
            {text="正在读 → 待读 → 已读完",checked_func=function()return globalSetting("sort_mode")=="status"end,callback=function()saveGlobal("sort_mode","status");sortBooks(self.books);self:buildPages();UIManager:setDirty(self,"ui")end},
            {text="书名",checked_func=function()return globalSetting("sort_mode")=="title"end,callback=function()saveGlobal("sort_mode","title");sortBooks(self.books);self:buildPages();UIManager:setDirty(self,"ui")end},
            {text="添加日期",checked_func=function()return globalSetting("sort_mode")=="added"end,callback=function()saveGlobal("sort_mode","added");sortBooks(self.books);self:buildPages();UIManager:setDirty(self,"ui")end},
            {text="阅读日期",checked_func=function()return globalSetting("sort_mode")=="read"end,callback=function()saveGlobal("sort_mode","read");sortBooks(self.books);self:buildPages();UIManager:setDirty(self,"ui")end},
    }
    local folder_items = {
        {text_func=function()return "当前："..libraryRoot()end,enabled_func=function()return false end},
        {text="使用当前 Kindle 书库",callback=function()
            if settings_menu then UIManager:close(settings_menu) end
            self:setLibraryRoot(nil)
        end},
        {text="选择其他文件夹…",callback=function()
            if settings_menu then UIManager:close(settings_menu) end
            local PathChooser = require("ui/widget/pathchooser")
            UIManager:show(PathChooser:new{
                path=libraryRoot(),select_directory=true,select_file=false,show_files=false,
                onConfirm=function(folder) self:setLibraryRoot(folder) end,
            })
        end},
    }
    local items = {
        {text="立体度",sub_item_table={
            {text="书本",sub_item_table=fiveLevels("book_3d_level",{1,2,3,4},{"一档 · 最弱 · 浅灰","二档 · 较弱 · 中灰","三档 · 较强 · 深灰","四档 · 最强 · 近黑"})},
            {text="书架",sub_item_table=fiveLevels("shelf_3d_level",{1,2,3,4},{"一档 · 最弱 · 浅灰","二档 · 较弱 · 中灰","三档 · 较强 · 深灰","四档 · 最强 · 近黑"})},
        }},
        {text="隔板",sub_item_table={
            {text="行数",sub_item_table=fiveLevels("shelf_rows",{1,2,3,4,5},{"一行","二行","三行 · 默认","四行","五行"})},
            {text="厚度",sub_item_table=fiveLevels("shelf_thickness",{16,20,24,30,36},{"一档 · 最窄","二档 · 较窄","三档 · 适中","四档 · 较宽","五档 · 最宽"})},
        }},
        {text="全局默认",sub_item_table={
            {text="边距",sub_item_table={
                {text="左边距",sub_item_table=fiveLevels("book_left_margin_level",{1,2,3,4,5},{"一档 · 最窄","二档 · 默认","三档 · 适中","四档 · 较宽","五档 · 最宽"})},
                {text="右边距",sub_item_table=fiveLevels("book_right_margin_level",{1,2,3,4,5},{"一档 · 最窄","二档 · 默认","三档 · 适中","四档 · 较宽","五档 · 最宽"})},
                {text="上边留白",sub_item_table=fiveLevels("book_top_margin_level",{1,2,3,4,5},{"一档 · 最少","二档 · 较少","三档 · 默认","四档 · 较多","五档 · 最多"})},
            }},
            {text="字号",sub_item_table={
                {text_func=function()return "SimpleUI："..globalSetting("embedded_font_size")end,callback=function()spinner("SimpleUI 默认字号",globalSetting("embedded_font_size"),3,48,1,function(v)setTypography("embedded_font_size",v)end)end},
                {text_func=function()return "独立页面："..globalSetting("standalone_font_size")end,callback=function()spinner("独立页面默认字号",globalSetting("standalone_font_size"),3,48,1,function(v)setTypography("standalone_font_size",v)end)end},
            }},
            {text="字距",sub_item_table={
                {text_func=function()return "SimpleUI："..globalSetting("embedded_line_spacing")end,callback=function()spinner("SimpleUI 默认字距",globalSetting("embedded_line_spacing"),3,80,1,function(v)setTypography("embedded_line_spacing",v)end)end},
                {text_func=function()return "独立页面："..globalSetting("standalone_line_spacing")end,callback=function()spinner("独立页面默认字距",globalSetting("standalone_line_spacing"),3,80,1,function(v)setTypography("standalone_line_spacing",v)end)end},
            }},
            {text="排序方式",sub_item_table=sort_items},
            {text="书籍文件夹",sub_item_table=folder_items},
            {text="书本大小比例",sub_item_table={
                {text_func=function() return "当前："..(globalSetting("book_scale") or 100).."%" end,
                 callback=function() spinner("书本大小比例(%)", globalSetting("book_scale") or 100, 50, 150, 5, function(v) setGlobalAndPaint("book_scale", v) end) end},
            }},
        }},
    }
    items[#items + 1] = {text="壁纸",sub_item_table={
        {text="壁纸文件夹",sub_item_table=wallpaper_folder_items},
        {text="选择壁纸",sub_item_table=wallpaper_items},
        {text="填充方式",sub_item_table={
            {text="原尺寸",checked_func=function() return wallpaperFitMode() == "original" end,
             callback=function() setWallpaperFitMode("original"); self:clearWallpaperCache(); UIManager:setDirty(self,"ui") end},
            {text="拉伸",checked_func=function() return wallpaperFitMode() == "stretch" end,
             callback=function() setWallpaperFitMode("stretch"); self:clearWallpaperCache(); UIManager:setDirty(self,"ui") end},
            {text="铺满",checked_func=function() return wallpaperFitMode() == "fill" end,
             callback=function() setWallpaperFitMode("fill"); self:clearWallpaperCache(); UIManager:setDirty(self,"ui") end},
        }},
    }}
    if self.standalone then
        items[#items + 1] = {
            text = "退出 SimpleBookshelf",
            callback = function()
                if settings_menu then UIManager:close(settings_menu) end
                UIManager:close(self)
            end,
        }
    end
    settings_menu = Menu:new{title="SimpleBookshelf 全局设置",item_table=items,width=math.floor(Screen:getWidth()*.66),height=math.floor(Screen:getHeight()*.7)}
    UIManager:show(settings_menu)
end

function Shelf:onCloseAllMenus() UIManager:close(self); return true end
function Shelf:onClose() UIManager:close(self); return true end
function Shelf:onCloseWidget()
    self:clearWallpaperCache()
    if Shelf.instance == self then Shelf.instance = nil end
end

local Plugin = WidgetContainer:extend{ name="simplebookshelf" }

function Plugin:showShelf(sui_plugin, standalone)
    standalone = standalone == true
    if Shelf.instance and Shelf.instance.standalone ~= standalone then
        local old = Shelf.instance
        Shelf.instance = nil
        if UIManager:isWidgetShown(old) then UIManager:close(old) end
    end
    if Shelf.instance and not UIManager:isWidgetShown(Shelf.instance) then
        Shelf.instance = nil
    end
    if Shelf.instance then
        -- The current page owns the live navbar. Never mutate UIManager's
        -- private window stack here; doing so bypasses close callbacks and was
        -- the other source of dead navigation after a reader session.
        Shelf.instance.sui_plugin = sui_plugin or Shelf.instance.sui_plugin
        UIManager:setDirty(Shelf.instance,"ui")
        UIManager:scheduleIn(.1, function()
            if Shelf.instance then Shelf.instance:refreshBooks(false) end
        end)
        closeSwitchBlocker()
        return true
    end
    Shelf.instance = Shelf:new{ sui_plugin=sui_plugin or self.sui_plugin, owner_plugin=self, standalone=standalone }
    UIManager:show(Shelf.instance)
    closeSwitchBlocker()
    return true
end

-- Resolve a SimpleUI module by trying its 2.5.0 path first and falling back
-- to the legacy bare alias. SimpleUI 2.5.0 moved its modules under infra/ and
-- features/ and stopped registering bare require aliases (sui_config /
-- sui_quickactions), so the old require("sui_config") started failing and the
-- whole integration silently no-op'd.
function Plugin:_requireSui(mod_new, mod_old)
    local modules = SimpleUI.resolve()
    if not modules then return nil end
    local by_path = {
        ["infra/sui_core"] = modules.UI,
        ["sui_core"] = modules.UI,
        ["infra/sui_config"] = modules.Config,
        ["sui_config"] = modules.Config,
        ["infra/sui_store"] = modules.Store,
        ["sui_store"] = modules.Store,
        ["features/sui_quickactions"] = modules.Actions,
        ["sui_quickactions"] = modules.Actions,
        ["screens/sui_bottombar"] = modules.Bottombar,
        ["sui_bottombar"] = modules.Bottombar,
        ["features/sui_style"] = modules.Style,
        ["sui_style"] = modules.Style,
    }
    return by_path[mod_new] or by_path[mod_old]
end

-- Best-effort lookup of the live SimpleUI plugin instance (needed to rebuild
-- its navbar). Prefer the FileManager reference; fall back to the module cache.
function Plugin:_resolveSuiPlugin()
    local fm = self.ui
    if not (fm and fm._simpleui_plugin) then
        local FM = package.loaded["apps/filemanager/filemanager"]
        fm = FM and FM.instance
    end
    return (fm and fm._simpleui_plugin) or self.sui_plugin or nil
end

function Plugin:registerSimpleUI()
    if self._simpleui_registered then return true end
    local Config  = self:_requireSui("infra/sui_config", "sui_config")
    local Actions = self:_requireSui("features/sui_quickactions", "sui_quickactions")
    if not (Config and Actions) then
        -- SimpleUI not loaded yet (plugin load order differs). Caller retries.
        return false
    end
    local owner=self
    SimpleUI.registerAction{
        id="simplebookshelf",label="SimpleBookshelf",icon=PLUGIN_DIR.."/bookshelf.svg",
        -- This is a real navigable page, not a dialog/toggle. Marking it
        -- in-place prevents SimpleUI from closing the previous page and
        -- rebuilding its touch zones when switching from bookshelf-home.
        is_in_place=false,
        execute=function(context)
            local sui_plugin = (context and context.plugin)
                or owner:_resolveSuiPlugin()
                or owner.sui_plugin
            owner.sui_plugin = sui_plugin
            local old = Shelf.instance
            -- Navigation has already closed the previous auxiliary page.
            -- Resolve a deferred singleton immediately so we never stop on the
            -- native library while waiting for a timer callback.
            if old and not UIManager:isWidgetShown(old) and Shelf.instance == old then
                Shelf.instance = nil
            end
            owner:showShelf(sui_plugin)
        end,
    }
    self._simpleui_registered = true
    if Config.invalidateTabsCache then Config.invalidateTabsCache() end
    -- SimpleUI owns the saved tab list. Do not add, remove, or migrate tabs
    -- here: the current list is read dynamically whenever a page is wrapped.
    -- If SimpleUI is already on screen, rebuild it using that current list.
    self:_rebuildNavbar(Config)
    logger.info("simplebookshelf: integrated SimpleUI bookshelf registered")
    return true
end

function Plugin:_rebuildNavbar(Config)
    local Bottombar = self:_requireSui("screens/sui_bottombar", "sui_bottombar")
    if not (Bottombar and Bottombar.rebuildAllNavbars) then return end
    local sui_plugin = self:_resolveSuiPlugin()
    if sui_plugin then
        pcall(Bottombar.rebuildAllNavbars, sui_plugin)
    end
end

function Plugin:init()
    Dispatcher:init()
    Dispatcher:registerAction("simplebookshelf_show",{category="none",event="ShowSimpleBookshelf",title="打开书柜",general=true})
    self:registerSimpleUI()
    if not self._simpleui_registered then
        -- SimpleUI may be loaded after this plugin. Retry on a timer until it is
        -- available so the navbar tab is registered regardless of load order.
        local owner = self
        local attempts = 0
        UIManager:scheduleIn(0.3, function()
            local function retry()
                attempts = attempts + 1
                if owner._simpleui_registered then return end
                if owner:registerSimpleUI() then return end
                if attempts < 40 then UIManager:scheduleIn(0.5, retry) end
            end
            retry()
        end)
    end
end
function Plugin:onShowSimpleBookshelf()
    if Shelf.instance and Shelf.instance.standalone and UIManager:isWidgetShown(Shelf.instance) then
        UIManager:close(Shelf.instance)
        return true
    end
    return self:showShelf(self.sui_plugin, true)
end
function Plugin:onCloseDocument()
    if not G_reader_settings:isTrue("simplebookshelf_return_pending") then return end
    local standalone = G_reader_settings:isTrue("simplebookshelf_return_standalone")
    local return_page = tonumber(G_reader_settings:readSetting("simplebookshelf_return_page")) or 1
    G_reader_settings:delSetting("simplebookshelf_return_pending")
    G_reader_settings:delSetting("simplebookshelf_return_standalone")
    G_reader_settings:delSetting("simplebookshelf_return_page")
    G_reader_settings:flush()
    logger.info("simplebookshelf: document closed, evaluating bookshelf return")
    local owner = self
    UIManager:nextTick(function()
        -- A CloseDocument event is also emitted during KOReader shutdown. In
        -- that path reopening a shelf leaves a live window on the stack and
        -- makes the navbar look frozen. Only return when a live FileManager
        -- exists after the reader transition.
        if applicationIsClosing() then
            closeShelfInstance()
            return
        end
        local fm = liveFileManager()
        if not fm then
            closeShelfInstance()
            logger.warn("simplebookshelf: no FileManager after document close; not reopening")
            return
        end
        local simpleui = fm._simpleui_plugin
        if simpleui then owner.sui_plugin = simpleui end
        owner:showShelf(simpleui or owner.sui_plugin, standalone)
        local shelf = Shelf.instance
        if shelf then
            shelf.page = math.max(1, math.min(return_page, shelf.page_num or return_page))
            UIManager:setDirty(shelf, "ui")
        end
    end)
    -- Leave provenance visible long enough for every plugin's
    -- onCloseDocument handler to observe it, regardless of dispatch order.
    UIManager:scheduleIn(2, function()
        if G_reader_settings:readSetting("simpleui_book_origin") == "simplebookshelf" then
            G_reader_settings:delSetting("simpleui_book_origin")
            G_reader_settings:flush()
        end
        if UIManager._simpleui_book_origin == "simplebookshelf" then
            UIManager._simpleui_book_origin = nil
        end
    end)
end
function Plugin:addToMainMenu(items) items.simplebookshelf={text="打开 SimpleBookshelf",sorting_hint="tools",callback=function()self:showShelf(self.sui_plugin,true)end} end
function Plugin:onCloseWidget()
    -- Keep the registered navbar action alive for the lifetime of SimpleUI.
    -- Unregistering it whenever FileManager closes is what made later navbar
    -- taps appear dead after a reader exit.
    if applicationIsClosing() then
        closeShelfInstance()
        return
    end
    if self.ui and self.ui.tearing_down then return end
    closeShelfInstance()
end

return Plugin
